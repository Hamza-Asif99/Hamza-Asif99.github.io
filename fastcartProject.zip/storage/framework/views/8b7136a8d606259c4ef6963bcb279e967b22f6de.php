<!DOCTYPE html>
<html lang="en">
<head>

    <title>Admin Portal</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="design.css">  
    <!-- <script defer src="validation.js"></script> -->

</head>
<body>

    

    <?php $__env->startSection('content'); ?>
        <div class="container itemsDisplay">
            <div class="center text-center">
                <h3>Welcome To The Admin Portal</h3>
                
            </div>
            <div class="col-12 text-center">

                    <a href="/items">
                    
                        <ul class="li btn btn-default">Add Record</ul>
                    </a>
                    
                </div>
            <div class="row">
                <?php if(count($items) > 0): ?>
                <table class="table text-light" style="background-color: rgba(1, 1, 1, 0.8)">
                    <div class="text-warning text-center p-4" style="background-color: rgba(1, 1, 1, 0.8)">Current Database</div>
                    <thead class="text-warning">
                        <tr>
                        <th scope="col">id</th>
                        <th scope="col">Title</th>
                        <th scope="col">Image-src</th>
                        <th scope="col">Price</th>
                        <th scope="col">Description</th>
                        <th scope="col">Category</th>
                        <th scope="col">Remove</th>
                        <th scope="col">Edit</th>
                        </tr>
                    </thead>
                    <tbody>
                       <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e($item->image); ?></td>
                                <td><?php echo e($item->price); ?></td>
                                <td><?php echo e($item->desc); ?></td>
                                <td><?php echo e($item->category); ?></td>

                                <td><a href="<?php echo e(route('item.destroy',$item->id)); ?>"><i class="far fa-times-circle" style="color:red"></i></a></td>
                                <td>
                                    <a href="<?php echo e(route('toChange.toChange', $item->id)); ?>"><button class="btn">Edit</button></a>
                                </td>
                                
                            
                            </tr>

                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
 
                <?php else: ?>
                    <p>No Items Added</p>
                <?php endif; ?>


        
                
            </div>
        </div>

    <?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\fastcart\resources\views/admin.blade.php ENDPATH**/ ?>