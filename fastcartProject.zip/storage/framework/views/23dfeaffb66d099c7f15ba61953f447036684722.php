<!DOCTYPE html>
<html lang="en">
<head>
   
    <title>Categories Page</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <link rel="stylesheet" href="design.css">
    <script defer src="categories.js"></script>
    <script defer src="validation.js"></script>

</head>

<body>
    


    <?php $__env->startSection('content'); ?>

    <?php if(count($items)>0): ?>
        <div class="container itemsDisplay">
            <div class="center text-center">
                <h3 ><?php echo e($items[0]->category); ?></h3>
            </div>
            <div class="row">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-sm-6 col-md-4">
                    <div class="item">
                        <!-- echo <?php echo e($item->id); ?> -->
                        <a href="/item" class="anchor">

                        <img src="<?php echo e($item->image); ?>" id="images" alt="Item display">
                        <div class="details">

                            <h2 id="title"><?php echo e($item->title); ?></h2>
                            <span id="price">$<?php echo e($item->price); ?></span>
                        </div>
                        <p id="description"><?php echo e($item->desc); ?></p>
                        </a>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
        

    <?php else: ?>
        <h3>no data</h3>

    <?php endif; ?>



    <?php $__env->stopSection(); ?>
    
      
</body>
</html>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\fastcart\resources\views/categories.blade.php ENDPATH**/ ?>